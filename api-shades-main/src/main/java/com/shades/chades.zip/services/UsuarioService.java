package com.shades.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shades.models.UsuarioModelo;
import com.shades.repositories.UsuarioRepository;

@Service
public class UsuarioService {
	
	@Autowired
	private  UsuarioRepository usuarioRepository;
	
	public ArrayList<UsuarioModelo> obtenerUsuario(){
		return (ArrayList<UsuarioModelo>) usuarioRepository.findAll();
    }
}
