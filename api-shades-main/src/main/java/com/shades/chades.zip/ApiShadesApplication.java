package com.shades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiShadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiShadesApplication.class, args);
	}

}
