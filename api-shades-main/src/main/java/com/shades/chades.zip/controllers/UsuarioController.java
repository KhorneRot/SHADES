package com.shades.controllers;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shades.models.UsuarioModelo;
import com.shades.services.UsuarioService;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {
	
	@Autowired
	UsuarioService usuarioService;
	
	@GetMapping() // http://localhost/8080/api/usuarios
	public ArrayList<UsuarioModelo> obtenerUsuarios() {
		return usuarioService.obtenerUsuario();
	}
}
