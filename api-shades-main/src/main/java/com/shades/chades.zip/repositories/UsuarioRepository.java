package com.shades.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.shades.models.UsuarioModelo;

@Repository
public interface UsuarioRepository extends CrudRepository<UsuarioModelo, Long>{
	
	
}
